@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_dashboard.ps1"
exit /b %ERRORLEVEL%
